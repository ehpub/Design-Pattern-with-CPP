#pragma once
#include "EHApp.h"
class MyApp :
    public EHApp
{
public:
    virtual EHView* MakeView();
};

