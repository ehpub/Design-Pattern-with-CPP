#include "MyView.h"
#include <iostream>
using std::cout;
using std::endl;
MyView::MyView()
{
	cout << "MyView ����" << endl;
}
MyView::~MyView()
{
	cout << "MyView �Ҹ�" << endl;
}
void MyView::Show()
{
	cout << "MyView Show..." << endl;
}