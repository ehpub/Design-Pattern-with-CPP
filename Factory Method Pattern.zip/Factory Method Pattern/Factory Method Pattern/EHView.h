#pragma once
#include <iostream>
using std::cout;
using std::endl;
class EHView
{
public:
	virtual void Show() = 0;
	virtual ~EHView();

};

