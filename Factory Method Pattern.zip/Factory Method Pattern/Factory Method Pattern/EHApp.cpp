#include "EHApp.h"
void EHApp::InitInstance()
{
	view = MakeView();
}
void EHApp::Run()
{
	view->Show();
}
#include <iostream>
using std::cout;
using std::endl;
void EHApp::Exit()
{
	cout << "���ķ�" << endl;
	delete view;
}