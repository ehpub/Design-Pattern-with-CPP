#pragma once
#include "EHView.h"
class MyView :
    public EHView
{
public:
    MyView();
    virtual ~MyView();
    void Show();
};

