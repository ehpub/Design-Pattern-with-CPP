#include "EHView.h"
#include <iostream>
using std::cout;
using std::endl;
EHView::~EHView()
{
}
