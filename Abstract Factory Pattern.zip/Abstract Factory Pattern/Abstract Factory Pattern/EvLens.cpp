#include "EvLens.h"
#include <iostream>
using namespace std;
using std::cout;
using std::endl;
void EvLens::Take()
{
	cout << "�ε巴��~~" << endl;
}
void EvLens::AutoFocus()
{
	cout << "��~��~��" << endl;
}