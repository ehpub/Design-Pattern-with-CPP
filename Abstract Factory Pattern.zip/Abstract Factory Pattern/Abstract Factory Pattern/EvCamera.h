#pragma once
#include "Camera.h"
class EvCamera :
    public Camera
{
public:
    virtual bool PutInLens(Lens* lens);
    virtual bool TakeAPicture();
};

