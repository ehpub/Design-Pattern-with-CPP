#include "Camera.h"

Camera::Camera(void)
{
	lens = 0;
}
bool Camera::TakeAPicture()
{
	if (lens ==0)
	{
		return false;
	}
	lens->Take();
	return true;
}
Lens* Camera::GetOutLens() 
{
	Lens* lens = GetLens();
	SetLens(0);
	return lens;
}
void Camera::SetLens(Lens* lens)
{
	this->lens = lens;
}
Lens* Camera::GetLens()
{
	return lens;
}