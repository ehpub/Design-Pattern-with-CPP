#pragma once
#include "Lens.h"
class Camera
{
	Lens* lens;
public:
	Camera(void);
	virtual bool PutInLens(Lens* lens) = 0;
	virtual bool TakeAPicture();
	Lens* GetOutLens();	
protected:
	void SetLens(Lens* lens);
	Lens* GetLens();
};

