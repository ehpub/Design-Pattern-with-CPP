#include "EvCamera.h"
#include "EvLens.h"
bool EvCamera::PutInLens(Lens* lens)
{
	EvLens* evlens = dynamic_cast<EvLens*>(lens);
	if (evlens == 0) //lens�� EvLens�� �ƴ� ��
	{
		return false;
	}
	SetLens(lens);
	return true;
}
bool EvCamera::TakeAPicture()
{
	Lens* lens = GetLens();
	EvLens* evlens = dynamic_cast<EvLens*>(lens);
	if (evlens == 0)
	{
		return false;
	}
	evlens->AutoFocus();
	return Camera::TakeAPicture();
}