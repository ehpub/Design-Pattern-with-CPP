#include "HoCamera.h"
#include "HoLens.h"
bool HoCamera::PutInLens(Lens* lens)
{
	HoLens* holens = dynamic_cast<HoLens*>(lens);
	if (holens == 0) //lens�� HoLens�� �ƴ� ��
	{
		return false;
	}
	SetLens(lens);
	return true;
}
bool HoCamera::TakeAPicture()
{
	Lens* lens = GetLens();
	HoLens* holens = dynamic_cast<HoLens*>(lens);
	if (holens == 0)
	{
		return false;
	}
	holens->ManualFocus();
	return Camera::TakeAPicture();
}