#include "Array.h"
#include <iostream>
using std::cout;
using std::endl;
int main()
{
	Array* arr = new Array();
	arr->PushBack(1);
	arr->PushBack(2);
	arr->PushBack(3);
	for (int i = 0; i < arr->GetUsage(); i++)
	{
		cout << (*arr)[i] << endl;
	}
	Array* arr2 = arr->Clone();
	arr2->PushBack(5);
	cout << "=====" << endl;
	for (int i = 0; i < arr->GetUsage(); i++)
	{
		cout << (*arr)[i] << endl;
	}
	cout << "=====" << endl;
	for (int i = 0; i < arr2->GetUsage(); i++)
	{
		cout << (*arr2)[i] << endl;
	}

	delete arr;
	return 0;
}