#pragma once
class Array
{
	int capacity;
	int usage;
	int* base;
public:
	Array();
	void PushBack(int value);
	int GetUsage()const;
	Array* Clone();
	int operator[](int index);
private:
	void Extend(int size);
};