#include "Array.h"
#include <string.h>
Array::Array()
{
	capacity = 1;
	usage = 0;
	base = new int[capacity];
}
void Array::PushBack(int value)
{
	if (capacity == usage)
	{
		Extend(2 * capacity);
	}
	base[usage] = value;
	usage++;
}
int Array::GetUsage()const
{
	return usage;
}
Array* Array::Clone()
{
	Array* arr = new Array();
	for (int i = 0; i < usage; i++)
	{
		arr->PushBack(base[i]);
	}
	return arr;
}
int Array::operator[](int index)
{
	if(index<0 || index>=usage)
	{ 
		throw "��";
	}
	return base[index];
}
void Array::Extend(int size)
{
	int* tb = base;
	base = new int[size];
	memcpy(base, tb, sizeof(int) * usage);
	delete[] tb;
}