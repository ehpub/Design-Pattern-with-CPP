#pragma once
#include "common.h"
typedef string Picture;

class PictureBuilder
{
	Picture picture;
public:
	PictureBuilder();
	Picture GetPicture();
	void SetPicture(string origin);
	virtual void CollectImage() = 0;
	virtual void Change() = 0;
};

