#include "PictureBuilder.h"
PictureBuilder::PictureBuilder()
{
	SetPicture("");
}
Picture PictureBuilder::GetPicture()
{
	return picture;
}
void PictureBuilder::SetPicture(string origin)
{
	picture = origin;
}