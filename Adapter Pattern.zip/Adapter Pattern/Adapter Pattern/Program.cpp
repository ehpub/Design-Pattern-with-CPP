#include "Camera.h"
#include "WrapAImageProcessor.h"
#include "PImageProcessor.h"
int main()
{
	ImageProcessor* ips[2];
	ips[0] = new PImageProcessor();
	ips[1] = new WrapAImageProcessor();

	Camera* camera = new Camera(ips[0]);
	string picture = camera->TakeAPicture("people animal book people animal");
	cout << picture << endl;

	camera->UpgradeFirmWare(ips[1]);
	picture = camera->TakeAPicture("people animal book people animal");
	cout << picture << endl;
	delete camera;
	delete ips[0];
	delete ips[1];
	return 0;
}