#pragma once
#include "ImageProcessor.h"
class PImageProcessor :
    public ImageProcessor
{
	string subject;
	string picture;
	int index;
	int oindex;
public:
	PImageProcessor();
	virtual void SetSubject(string subject);
	virtual void FindBegin();
	virtual bool FindNextPeople();
	virtual void ImageProcessing();
	virtual string GetPicture();
};

