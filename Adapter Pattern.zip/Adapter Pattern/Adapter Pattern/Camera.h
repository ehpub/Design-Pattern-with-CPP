#pragma once
#include "ImageProcessor.h"
class Camera
{
	ImageProcessor* img_processor;
public:
	Camera(ImageProcessor* img_processor);
	string TakeAPicture(string subject);
	void UpgradeFirmWare(ImageProcessor* img_processor);
};

