#include "AImageProcessor.h"
AImageProcessor::AImageProcessor()
{
	image = "";
	picture = "";
	index = -1;
	oindex = -1;
}
void AImageProcessor::SetOrigin(string image)
{
	this->image = image;
}
void AImageProcessor::FindStart()
{
	picture = image;
	index = -1;
	oindex = -1;
}
bool AImageProcessor::FindNextAnimal()
{
	oindex = index;
	index = image.find("animal", oindex + 1);
	return index != -1;
}
void AImageProcessor::Processing()
{
	picture.replace(index, strlen("animal"), "ANIMAL");
}
string AImageProcessor::GetPicture()
{
	return picture;
}