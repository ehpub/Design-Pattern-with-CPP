#pragma once
#include "ImageProcessor.h"
#include "AImageProcessor.h"
class WrapAImageProcessor:
	public ImageProcessor
{
	AImageProcessor* ai_processor;
public:
	WrapAImageProcessor();
	~WrapAImageProcessor();
	virtual void SetSubject(string subject);
	virtual void FindBegin();
	virtual bool FindNextPeople();
	virtual void ImageProcessing();
	virtual string GetPicture();
};

