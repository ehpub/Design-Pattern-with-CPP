#include "Camera.h"
Camera::Camera(ImageProcessor* img_processor)
{
	this->img_processor = img_processor;
}
string Camera::TakeAPicture(string subject)
{
	int index = 0;	
	img_processor->SetSubject(subject);
	img_processor->FindBegin();
	while (img_processor->FindNextPeople())
	{
		img_processor->ImageProcessing();
	}
	return img_processor->GetPicture();
}
void Camera::UpgradeFirmWare(ImageProcessor* img_processor)
{
	this->img_processor = img_processor;
}