#include "ZoomLens.h"
#include "common.h"
int ZoomLens::ZoomIn()//Ȯ��
{
	int nz = zoom;
	cout <<"Ȯ�� �� Zoom:"<< zoom << endl;
	cout << "Ȯ��" << endl;
	nz += step;
	if (nz > max_zoom)
	{
		nz = max_zoom;
	}
	SetZoom(nz);
	cout << "Ȯ�� �� Zoom:" << zoom << endl;
	return GetZoom();
}
int ZoomLens::ZoomOut()//���
{
	int nz = zoom;
	cout << "��� �� Zoom:" << zoom << endl;
	cout << "���" << endl;
	nz -= step;
	if (nz < min_zoom)
	{
		nz = min_zoom;
	}
	SetZoom(nz);
	cout << "��� �� Zoom:" << zoom << endl;
	return GetZoom();
}
ZoomLens* ZoomLens::Clone()//�ڱ� ����
{
	return new ZoomLens(min_zoom, max_zoom, step);
}
ZoomLens::ZoomLens(int min_zoom, int max_zoom, int step):
	min_zoom(min_zoom),max_zoom(max_zoom),step(step)
{
	zoom = min_zoom;
}
void ZoomLens::SetZoom(int zoom)
{
	this->zoom = zoom;
}
int ZoomLens::GetZoom()
{
	return this->zoom;
}
