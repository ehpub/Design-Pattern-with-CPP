#include "ProLine.h"
#include "common.h"
ProLine::ProLine()
{
	zarr[0] = new ZoomLens(10, 20, 1);
	zarr[1] = new ZoomLens(20, 40, 2);
	zarr[2] = new ZoomLens(10, 40, 4);
	zarr[3] = new ZoomLens(15, 25, 1);
	zarr[4] = new ZoomLens(15, 35, 2);
	zarr[5] = new ZoomLens(15, 50, 2);
	zarr[6] = new ZoomLens(2, 5, 1);
	zarr[7] = new ZoomLens(2, 100, 5);
	zarr[8] = new ZoomLens(5, 20, 1);
	zarr[9] = new ZoomLens(5, 50, 5);
}
ProLine::~ProLine()
{
	for (int i = 0; i < 10; i++)
	{
		delete zarr[i];
	}
}
void ProLine::ViewZoomLensList()
{
	ZoomLens* zl = 0;
	for (int i = 0; i < 10; i++)
	{
		zl = zarr[i];
		cout << i << "��° zoom lens" << endl;
		cout << zl->min_zoom << "~" << zl->max_zoom << endl;
		cout << "===" << endl;
	}
}
ZoomLens* ProLine::Order(int index)
{
	if (index < 0 || index >= 10)
	{
		cout << "�׷� ��ǰ ����Dragon~" << endl;
		return 0;
	}
	return zarr[index]->Clone();
}