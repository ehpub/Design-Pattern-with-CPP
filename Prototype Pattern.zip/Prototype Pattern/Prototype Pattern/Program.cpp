#include "ProLine.h"
#include "common.h"
int main()
{
	ProLine* pl = new ProLine();

	pl->ViewZoomLensList();
	ZoomLens* zl = pl->Order(2);
	cout << "���� Zoom" << zl->GetZoom() << endl;
	zl->ZoomIn();
	cout << "���� Zoom" << zl->GetZoom() << endl;
	delete zl;
	delete pl;
	return 0;
}