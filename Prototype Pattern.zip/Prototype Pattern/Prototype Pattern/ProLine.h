#pragma once
#include "ZoomLens.h"

class ProLine
{
	ZoomLens* zarr[10];
public:
	ProLine();
	~ProLine();
	void ViewZoomLensList();
	ZoomLens* Order(int index);
};

