#pragma once
#include "common.h"
class Picture
{
	int tone;//����
	int brightness;//����
	int saturation;//ä��
	const string name;
public:
	Picture(string name, int tone, int brightness, int saturation);
	void Change(int tone, int brightness, int saturation);
	bool IsEqual(string name);
	void View();
	string GetName()const;
};

