#include "SmartManager.h"
SmartManager::SmartManager()
{
	pm = new PictureManager();
	compensator = new Compensator();
}
SmartManager::~SmartManager()
{
	delete pm;
	delete compensator;
}
bool SmartManager::Exist(string name)
{
	return pm->Exist(name);
}
bool SmartManager::AddPicture(Picture* picture)
{
	return pm->AddPicture(picture);
}
Picture* SmartManager::FindPicture(string name)
{
	return pm->FindPicture(name);
}
bool SmartManager::Change(string name, int tone, int brightness, int saturation)
{
	Picture* picture = pm->FindPicture(name);
	if (picture == 0)
	{
		return false;
	}
	compensator->Change(picture, tone, brightness, saturation);
	return true;
}
void SmartManager::View()
{
	pm->View();
}