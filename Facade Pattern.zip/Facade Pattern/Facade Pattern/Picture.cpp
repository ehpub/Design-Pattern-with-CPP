#include "Picture.h"
Picture::Picture(string name, int tone, int brightness, int saturation):
	name(name)
{	
	this->brightness = brightness;
	this->tone = tone;
	this->saturation = saturation;
}
void Picture::Change(int tone, int brightness, int saturation)
{
	this->brightness += brightness;
	this->tone += tone;
	this->saturation += saturation;
}
bool Picture::IsEqual(string name)
{
	return this->name == name;
}
void Picture::View()
{
	cout << name << "###" << endl;
	cout << "tone:" << tone;
	cout << " ����:" << brightness;
	cout << " ä��:" << saturation << endl;
}
string Picture::GetName()const
{
	return name;
}