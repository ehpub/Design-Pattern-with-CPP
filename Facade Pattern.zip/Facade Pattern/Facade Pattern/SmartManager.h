#pragma once
#include "PictureManager.h"
#include "Compensator.h"
class SmartManager
{
	Compensator* compensator;
	PictureManager* pm;
public:
	SmartManager();
	~SmartManager();
	bool Exist(string name);
	bool AddPicture(Picture* picture);
	Picture* FindPicture(string name);
	bool Change(string name, int tone, int brightness, int saturation);
	void View();
};

