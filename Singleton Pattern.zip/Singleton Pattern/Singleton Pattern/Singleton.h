#pragma once

class Singleton
{
	static Singleton* unique_instance;
public:
	static Singleton* GetInstance();
private:
	Singleton(); 

};

