#include "Singleton.h"
#include <iostream>
using std::cout;
using std::endl;

Singleton* Singleton::unique_instance;
Singleton* Singleton::GetInstance()
{
	if (unique_instance == 0)
	{
		unique_instance = new Singleton();
	}
	return unique_instance;
}
Singleton::Singleton()
{
	cout << "����ü ����" << endl;
}