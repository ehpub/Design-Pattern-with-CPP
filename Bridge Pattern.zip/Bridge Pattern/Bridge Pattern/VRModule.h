#pragma once
#include "Module.h"
class VRModule :
    public Module
{
public:
    virtual string ImageProcessing(string subject);

};

