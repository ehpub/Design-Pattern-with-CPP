#pragma once
#include "Lens.h"
class Camera
{
	Lens* lens;
public:
	Camera();
	void PutInLens(Lens* lens);
	void TakeAPicture(string subject, int distance);
	void FocusUp();
	void FocusDown();
	void SetModuleIndex(int index);
	int GetModuleCount()const;
};

