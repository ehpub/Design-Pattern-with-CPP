#pragma once
#include "common.h"
class Module
{
public:
	virtual string ImageProcessing(string subject) = 0;
};

