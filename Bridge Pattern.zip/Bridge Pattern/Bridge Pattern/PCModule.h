#pragma once
#include "Module.h"
class PCModule:public Module
{
public:
	virtual string ImageProcessing(string subject);
};

