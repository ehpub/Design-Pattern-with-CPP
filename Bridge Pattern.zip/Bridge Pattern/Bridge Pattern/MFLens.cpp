#include "MFLens.h"
string MFLens::Take(string subject, int distance)
{	
	int mcount = GetModuleCount();
	for (int i = 0; i < mcount; i++)
	{
		subject = ImageProcessing(subject, i);
	}
	return MakePicture(subject, GetFocusLevel());
}
void MFLens::FocusUp()
{
	Lens::FocusUp();
	cout << "���� Focus Level:" << GetFocusLevel() << endl;
}
void MFLens::FocusDown()
{
	Lens::FocusDown();
	cout << "���� Focus Level:" << GetFocusLevel() << endl;
}